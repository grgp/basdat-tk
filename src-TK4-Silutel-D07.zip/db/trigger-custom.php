trigger-custom

select * from silutel.invoice where tanggaldatang='2016/26/05' order by tanggaldatang asc limit 5